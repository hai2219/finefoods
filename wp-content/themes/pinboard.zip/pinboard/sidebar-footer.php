<?php if( is_active_sidebar( 6 ) ) : ?>
	<div id="footer-area" class="widget-area" role="complementary">
		<?php dynamic_sidebar(6); ?>
		<div class="clear"></div>
	</div><!-- #footer-area -->
<?php endif; ?>