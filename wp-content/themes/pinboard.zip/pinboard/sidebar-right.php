<?php if( is_active_sidebar( 4 ) ) : ?>
	<div class="column twocol">
		<div id="sidebar-right" class="widget-area" role="complementary">
			<?php dynamic_sidebar( 4 ) ; ?>
		</div><!-- #sidebar-right -->
	</div><!-- .twocol -->
<?php endif; ?>